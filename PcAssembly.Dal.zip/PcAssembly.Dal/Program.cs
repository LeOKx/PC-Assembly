﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PcAssembly.Dal
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            //await using var dbContext = new DataContext();
            //dbContext.Database


        }
    }
}
